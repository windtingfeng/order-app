import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
    state:{
        foodslist:[]
    },
    mutations:{
        //初始化商品值
        changeFoodslist(state,list){
            state.foodslist = list
        },
        //购物车增加
        addFoods(state,num){
            let arr = state.foodslist
            for(let obj of arr){
                for(let pro of obj.foods){
                    if(pro.id == num.id){
                        pro.num ++
                        console.log(pro);
                        return
                    }
                }
            }
        }
    },
    getters:{
        getCarFoods(state){
            let foodarr = []
            for (let obj of state.foodslist) {
              for (let child of obj.foods) {
                if (child.num > 0) {
                  foodarr.push(child);
                }
              }
            }
            return foodarr
        }
    }
})